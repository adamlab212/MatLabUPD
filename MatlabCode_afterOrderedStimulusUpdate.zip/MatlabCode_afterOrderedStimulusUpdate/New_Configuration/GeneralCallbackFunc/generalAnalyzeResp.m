function generalAnalyzeResp(appHandle)
global  debug
global portAudio
global responseCorrectnessFeedback
global basicfig

feedbackString = 'nullresponse';

% ~(Michael Saar)~ --- DEBUG
disp('$ generalAnalyzeResp $');
analyzeResponseStartTime = toc;
wasCorrect = '';
% ~(Michael Saar)~ --- DEBUG END

%% explantion about the beeping sounds:
% there are 4 types of sounds in this function
%   1) a_legit (response recived) - when there was some response, either correct or
%   incorrect. Similar to the sound when response recived in experiments
%   with no sound-feedback.
%   2) a_timeout (nullresponse) - there was no response recived
%   3) a_legit_correct - when the response is correct.
%   4) a_non_legit & a_non_legit_2 - when the response is incorrect. Two
%   sounds are played consecutively


%%


% response recived
% a_legit
a = [ones(22,200);zeros(22,200)];
a_legit = a(:)'; 

% Received legit answer sound
% ~(Michael Saar)~ using makeBeep DONT DELETE THE FOLLOWONG LINE
% a = [ones(22,200);zeros(22,200)];
% DO NOT DELTE THE ABOVE LINE
% ~(Michael Saar)~  create sound for correct response
 a = MakeBeep(698, 0.4);
 a_legit_correct = a(:)';
 
% ~(Michael Saar)~ DO NOT DELETE THE FOLLOWING LINE
%  a_legit_correct = a(:);
% DO NOT DELETE THE ABOVE LINE

% Time Out Sound
a = [ones(220,25);zeros(220,25)];
a_timeout = a(:)';
% received non legit answer sound

% ~(Michael Saar)~ DO NOT DELETE THE FOLLOWING LINE
% a = [ones(110,50);zeros(110,50);ones(110,50)];
% DO NOT DELETE THE ABOVE LINE

% ~(Michael Saar)~  create sounds for incorrect response
a = MakeBeep(115, 0.4);
a_non_legit = a(:)';

%a_non_legit = a(:);

a = MakeBeep(85, 0.4);
a_non_legit_2 = a(:)';


if debug
    disp('Entering general analyzeResp')
end

trial = getappdata(appHandle,'trialInfo');
savedInfo = getappdata(appHandle,'SavedInfo');
data = getappdata(appHandle,'protinfo');
cldata = getappdata(appHandle, 'ControlLoopData');
crossVals = getappdata(appHandle,'CrossVals');
flagdata = getappdata(appHandle,'flagdata');

within = data.condvect.withinStair;
across = data.condvect.acrossStair;
varying = data.condvect.varying;

activeStair = data.activeStair;
activeRule = data.activeRule;
currRep = data.repNum;
currTrial = trial(activeStair,activeRule).cntr;

response = savedInfo(activeStair,activeRule).Resp(currRep).response(currTrial);

%Michael
% n = strmatch('DELTA',{char(data.configinfo.name)},'exact');
% delta_value = data.configinfo(n).parameters


%change the rsponse map if 2I , 4->1, 3->2
i = strmatch('MOTION_TYPE',{char(data.configinfo.name)},'exact');
if( data.configinfo(i).parameters == 3)
    if(response == 4)
        response = 1;
    elseif(response == 3)
        response = 2;
    end
end

HR = cldata.hReference;

if cldata.staircase % If it is staircase, use withinStair parameter to analyze Resp.
    if isfield(within.parameters, 'moog')
        dir = within.parameters.moog((trial(activeStair,activeRule).list(currTrial)));
    else
        dir = within.parameters((trial(activeStair,activeRule).list(currTrial)));
    end
    controlName = within.name;
else     %Else, use control parameter to analyze Resp.
    ind = get(findobj(appHandle,'Tag','controlParaPopupmenu'),'Value');
    if ~isempty(varying)  % if there are varying parameters, control para is got from them.
        dir = crossVals(trial.list(trial.cntr),ind);
        controlName = varying(ind).name;
    else    %else, control para is got from the parameters listing in the front panel
        str = get(findobj(appHandle,'Tag','controlParaPopupmenu'),'String');
        i = strmatch(char(str(ind)),{char(data.configinfo.nice_name)},'exact');
        if isfield(data.configinfo(i).parameters,'moog')
            dir = data.configinfo(i).parameters.moog;
        else
            dir = data.configinfo(i).parameters;
        end
        controlName = data.configinfo(i).nice_name;
    end
end

%control name is the one has different range of values.
%refernce name is the one which is const.
i = strmatch('MOTION_TYPE',{char(data.configinfo.name)},'exact');
is1IControl = 0;
if data.configinfo(i).parameters == 3   % For two interval
    if isempty(findstr(controlName,'2nd Int'))   % 1I parameter is a control parameter.
        refName = [controlName ' 2nd Int'];
        is1IControl = 1;
    else   % 2I parameter is a control parameter.
        refName = strtrim(strtok(controlName,'2'));
    end

    if ~isempty(strmatch(refName,{char(across.name)},'exact'))
        if isfield(across.parameters,'moog')
            dir2 = across.parameters.moog(activeStair);
        else
            dir2 = across.parameters(activeStair);
        end
    elseif ~isempty(strmatch(refName,{char(varying.name)},'exact'))
        ind = strmatch(refName,{char(varying.name)},'exact');
        if cldata.staircase
            dir2 = crossVals(cldata.varyingCurrInd,ind);
        else
            dir2 = crossVals(trial.list(trial.cntr),ind);
        end
    else
        ind = strmatch(refName,{char(data.configinfo.nice_name)},'exact');
        if isfield(data.configinfo(ind).parameters,'moog')
            dir2 = data.configinfo(ind).parameters.moog;
        else
            dir2 = data.configinfo(ind).parameters;
        end
    end
    
    %putting always the const as the tmpDir(2).
    if is1IControl %that what should be configured always.
        tmpDir(1) = dir;    %dir1 is test and varying
        tmpDir(2) = dir2;   %dir2 is reference and const
    else
        tmpDir(1) = dir2;   %dir2 is reference and varying
        tmpDir(2) = dir;    %dir1 is test and const
    end
    
    if HR 
        tmpDir(2) = tmpDir(2) + tmpDir(1);
    end 
    
    intOrder = getappdata(appHandle,'Order'); % setting directions same order as in trajectory
    %direction is the test (who is at 1st variable) minus the reference
    %(who is at 2nd variable).
    %remember tempDir(2) is always the const.
    dir = tmpDir(intOrder(2))- tmpDir(intOrder(1));
    %for regular situation where Diatance 1st is varying , and Distance 2nd
    %is const , and order is [1,2] (regular) , we get const-varying
    %dir<o if const<varying --> Distance2 < Distance1
    %dir>0 if const>varying --> Distance2 > Distance1
    
    savedInfo(activeStair,activeRule).Resp(currRep).intOrder(currTrial,:) = intOrder;
end

i = strmatch('MOTION_TYPE',{char(data.configinfo.name)},'exact');
if( data.configinfo(i).parameters == 3)
    savedInfo(activeStair,activeRule).Resp(currRep).dir(currTrial) = dir;
    savedInfo(activeStair,activeRule).Resp(currRep).distanceDiff(currTrial) = dir;
    if(is1IControl)
        savedInfo(activeStair,activeRule).Resp(currRep).refMinusTest(currTrial) = tmpDir(2) - tmpDir(1);
        savedInfo(activeStair,activeRule).Resp(currRep).refDir(currTrial) = tmpDir(2);
        savedInfo(activeStair,activeRule).Resp(currRep).testDir(currTrial) = tmpDir(1);
    else
        savedInfo(activeStair,activeRule).Resp(currRep).refMinusTest(currTrial) = tmpDir(1) - tmpDir(2);
        savedInfo(activeStair,activeRule).Resp(currRep).refDir(currTrial) = tmpDir(1);
        savedInfo(activeStair,activeRule).Resp(currRep).testDir(currTrial) = tmpDir(2);
    end
else
    savedInfo(activeStair,activeRule).Resp(currRep).dir(currTrial) = dir;
end

if response == 1 % Respond 1 %Left/Down
    if debug
        disp('You answered Left/Down')
    end
    
    if dir < 0
        if debug
            disp('correct')
        end
        feedbackString = 'Correct';
        savedInfo(activeStair,activeRule).Resp(currRep).corr(currTrial) = 1;
        savedInfo(activeStair,activeRule).Resp(currRep).incorr(currTrial) = 0;
        savedInfo(activeStair,activeRule).Resp(currRep).null(currTrial) = 0;
        savedInfo(activeStair,activeRule).Resp(currRep).dontKnow(currTrial) = 0;
    elseif dir > 0
        if debug
            disp('Not correct')
        end
        feedbackString = 'Not correct';
        savedInfo(activeStair,activeRule).Resp(currRep).corr(currTrial) = 0;
        savedInfo(activeStair,activeRule).Resp(currRep).incorr(currTrial) = 1;
        savedInfo(activeStair,activeRule).Resp(currRep).null(currTrial) = 0;
        savedInfo(activeStair,activeRule).Resp(currRep).dontKnow(currTrial) = 0;
    else
        if debug
            disp('No Answer')
        end
        feedbackString = 'No Answer';
        savedInfo(activeStair,activeRule).Resp(currRep).corr(currTrial) = 0;
        savedInfo(activeStair,activeRule).Resp(currRep).incorr(currTrial) = 0;
        savedInfo(activeStair,activeRule).Resp(currRep).null(currTrial) = 1;
        savedInfo(activeStair,activeRule).Resp(currRep).dontKnow(currTrial) = 0;
    end
elseif response == 2 % Respond 2 Right/Up
    if debug
        disp('you answered right/up')
    end
    if dir > 0
        if debug
            disp('correct')
        end
        feedbackString = 'Correct';
        savedInfo(activeStair,activeRule).Resp(currRep).corr(currTrial) = 1;
        savedInfo(activeStair,activeRule).Resp(currRep).incorr(currTrial) = 0;
        savedInfo(activeStair,activeRule).Resp(currRep).null(currTrial) = 0;
        savedInfo(activeStair,activeRule).Resp(currRep).dontKnow(currTrial) = 0;
    elseif dir < 0
        if debug
            disp('Not correct')
        end
        feedbackString = 'Not correct';
        savedInfo(activeStair,activeRule).Resp(currRep).corr(currTrial) = 0;
        savedInfo(activeStair,activeRule).Resp(currRep).incorr(currTrial) = 1;
        savedInfo(activeStair,activeRule).Resp(currRep).null(currTrial) = 0;
        savedInfo(activeStair,activeRule).Resp(currRep).dontKnow(currTrial) = 0;
    else
        if debug
            disp('No Answer')
        end
        feedbackString = 'No Answer';
        savedInfo(activeStair,activeRule).Resp(currRep).corr(currTrial) = 0;
        savedInfo(activeStair,activeRule).Resp(currRep).incorr(currTrial) = 0;
        savedInfo(activeStair,activeRule).Resp(currRep).null(currTrial) = 1;
        savedInfo(activeStair,activeRule).Resp(currRep).dontKnow(currTrial) = 0;
    end
elseif response == 3 % down only TEST ask Adam about what is right answer
    if debug
        disp('TEST 333')
        %temp = [delta_value, ' is delta'];
        %disp(temp);
    end
        feedbackString = 'Correct';
        savedInfo(activeStair,activeRule).Resp(currRep).corr(currTrial) = 0;
        savedInfo(activeStair,activeRule).Resp(currRep).incorr(currTrial) = 0;
        savedInfo(activeStair,activeRule).Resp(currRep).null(currTrial) = 1;
        savedInfo(activeStair,activeRule).Resp(currRep).dontKnow(currTrial) = 0;
elseif response == 4 % down only TEST
    if debug
        disp('TEST 444')
        %temp = [delta_value, ' is delta'];
        %disp(temp);
    end
        feedbackString = 'Incorrect';
        savedInfo(activeStair,activeRule).Resp(currRep).corr(currTrial) = 0;
        savedInfo(activeStair,activeRule).Resp(currRep).incorr(currTrial) = 0;
        savedInfo(activeStair,activeRule).Resp(currRep).null(currTrial) = 1;
        savedInfo(activeStair,activeRule).Resp(currRep).dontKnow(currTrial) = 0;
else % Unrecognized answer  Question: What to do when straight ahead is the heading? There is not corr/incorr
    if debug
        disp('Time Expired: Move Faster!!')
    end
    savedInfo(activeStair,activeRule).Resp(currRep).corr(currTrial) = 0;
    savedInfo(activeStair,activeRule).Resp(currRep).incorr(currTrial) = 0;
    savedInfo(activeStair,activeRule).Resp(currRep).null(currTrial) = 1;
    savedInfo(activeStair,activeRule).Resp(currRep).dontKnow(currTrial) = 0;
end


savedInfo(activeStair,activeRule).Resp(currRep).totalCorr = sum(savedInfo(activeStair,activeRule).Resp(currRep).corr);
savedInfo(activeStair,activeRule).Resp(currRep).totalIncorr = sum(savedInfo(activeStair,activeRule).Resp(currRep).incorr);
savedInfo(activeStair,activeRule).Resp(currRep).totalNull = sum(savedInfo(activeStair,activeRule).Resp(currRep).null);
savedInfo(activeStair,activeRule).Resp(currRep).totalDontKnow = sum(savedInfo(activeStair,activeRule).Resp(currRep).dontKnow);

if~isempty(across)
    if isfield(across.parameters, 'moog')   % Adds in the across staircase value into the 'SavedInfo' matrix
        savedInfo(activeStair,activeRule).Resp(currRep).acrossVal = across.parameters.moog(activeStair);
    else
        savedInfo(activeStair,activeRule).Resp(currRep).acrossVal = across.parameters(activeStair);
    end
else
    savedInfo(activeStair,activeRule).Resp(currRep).acrossVal = '';
end

setappdata(appHandle,'SavedInfo',savedInfo);

trialfeedbackInfo = get(findobj(basicfig,'Tag','listBoxFeedbackTrial') , 'String');
trialfeedbackInfo{end+1}= ['Discrimination correctness :' feedbackString];
set(findobj(basicfig,'Tag','listBoxFeedbackTrial') , 'String' , trialfeedbackInfo);

%giving feedback sound correctness in the analyze stage.
if responseCorrectnessFeedback
    if savedInfo(activeStair,activeRule).Resp(currRep).corr(currTrial) == 1
        % ~(Michael Saar)~ --- DEBUG
        wasCorrect = 'correct';
        % ~(Michael Saar)~ --- END
        % ~(Michael Saar)~ sound of response recived
        PsychPortAudio('FillBuffer', portAudio, [a_legit; a_legit]);
        PsychPortAudio('Start', portAudio, 1,0);
        % ~(Michael Saar)~ pause to seperate response-recived sound and
        % correct response sound
        % second version of pause: using tic, toc and while:
        %tic;
        timer_start = toc;
        timer_end = toc;
        while timer_end - timer_start < 0.5 %AZ 2022_08_18 updated from 0.8 to 0.5
            timer_end = toc;
        end
        %pause(0.8);  %Michael for DEBUG originally the value was 0.8
        % play the correct-response sound.
        PsychPortAudio('FillBuffer', portAudio, [a_legit_correct; a_legit_correct]);
        PsychPortAudio('Start', portAudio, 1,0);
        % ~(Michael)~ making the beep go twice by using pause() and calling
        % PsychPortAudio() again with the same parameters.
        %pause(0.4);
        % second version of pause: using tic, toc and while:
        %tic;
        timer_start = toc;
        timer_end = toc;
        while timer_end - timer_start < 0.1
            timer_end = toc;
        end
        %pause(0.1); %Yael & Shir changed 
        PsychPortAudio('FillBuffer', portAudio, [a_legit_correct; a_legit_correct]);
        PsychPortAudio('Start', portAudio, 1,0);
        % ~(Michael Saar)   END
    elseif response == 0
        % ~(Michael Saar)~ --- DEBUG
        wasCorrect = 'timeout';
        % ~(Michael Saar)~ --- END
        PsychPortAudio('FillBuffer', portAudio, [a_timeout; a_timeout]);
        PsychPortAudio('Start', portAudio, 1,0);
    else 
        % ~(Michael Saar)~ --- DEBUG
        wasCorrect = 'incorrect';
        % ~(Michael Saar)~ --- END
        % sound of response recived
        PsychPortAudio('FillBuffer', portAudio, [a_legit; a_legit]);
        PsychPortAudio('Start', portAudio, 1,0);
        % ~(Michael Saar)~ pause to seperate response-recived sound and
        % incorrect response sounds
        % second version of pause: using tic, toc and while:
        timer_start = toc;
        timer_end = toc;
        while timer_end - timer_start < 0.5 %AZ 2022_08_18 updated from 0.8 to 0.5
            timer_end = toc;
        end
        %pause(0.8);  %Michael for DEBUG originally the value was 0.8
        % sound of INCORRECT response
        PsychPortAudio('FillBuffer', portAudio, [a_non_legit; a_non_legit]);
        PsychPortAudio('Start', portAudio, 1,0);
        % ~(Michael)~ making the beep go twice by using pause() and calling
        % PsychPortAudio() again with other parameters.
        %pause(0.4);
        % second version of pause: using tic, toc and while:
        timer_start = toc;
        timer_end = toc;
        while timer_end - timer_start < 0.1
            timer_end = toc;
        end
        %pause(0.1); %Yael & Shir changed
        PsychPortAudio('FillBuffer', portAudio, [a_non_legit_2; a_non_legit_2]);
        PsychPortAudio('Start', portAudio, 1,0);
    end 
end

if debug || flagdata.isSubControl
    if savedInfo(activeStair,activeRule).Resp(currRep).corr(currTrial) == 1
        %%soundsc(data.correctWav,42000);
    else
        %%soundsc(data.wrongWav,42000);
    end
    disp('Exiting general analyzeResp')
end
% ~(Michael Saar) --- DEBUG
analyzeResponseEndTime = toc;
disp(fprintf('$ Exiting general analyzeResp $ # it took total of %f seconds, choice was %s #',(analyzeResponseEndTime - analyzeResponseStartTime), wasCorrect));
disp(fprintf('$ Exiting general analyzeResp $ # at time: %f',toc)); % AZ 8/18/2022 --- DEBUG
% ~(Michael Saar) --- END


