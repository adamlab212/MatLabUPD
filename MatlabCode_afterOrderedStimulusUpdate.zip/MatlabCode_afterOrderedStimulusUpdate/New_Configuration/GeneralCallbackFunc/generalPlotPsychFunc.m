function generalPlotPsychFunc(appHandle)

global debug

if debug
    disp('Entering general plotPsychFunc')
end

if debug
    disp('Exiting general plotPsychFunc')
end


