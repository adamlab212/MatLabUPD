function Conflict_plotPsychFunc(appHandle)

 global debug
 
 if debug
     disp('Entering Conflict plotPsychFunc')
 end

 if debug
     disp('Exiting Conflict plotPsychFunc')
 end 