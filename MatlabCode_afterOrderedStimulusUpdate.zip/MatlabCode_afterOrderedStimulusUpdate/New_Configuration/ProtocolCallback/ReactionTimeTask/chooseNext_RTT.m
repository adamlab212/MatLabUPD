function chooseNext_RTT(appHandle)

global debug

if debug
    disp('Entering chooseNext_RTT')
end

if debug
    disp('Exiting chooseNext_RTT')
end