% Access protocol parameters:
% find the index of the parameter in the parameters list:
i = strmatch('DELTA',{char(data.configinfo.name)},'exact'); 
% accesss the data in that index. 'parameters' has the value of the
% parameter 'DELTA'
data.configinfo(i).parameters
% check if this is CausalInferenceExplicit protocol
is_causal_inference_explicit = ~isempty(strmatch(data.configfile, 'CausalInferenceExplicit.mat', 'exact'));