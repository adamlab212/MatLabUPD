//***********************************************************************//
//  cbDInitServer                                                        //
//                                                                       //
//  Sets up the server digital I/O ports and sets alls bits to zero.     //
//                                                                       //
//  @Author:    Christopher Broussard                                    //
//  @Date:      December, 2005                                           //
//***********************************************************************//
#include <mex.h>
#include <cbw.h>

void mexFunction(int nlhs, mxArray *plhs[], int nrhs, const mxArray *prhs[])
{
    
}