function plotPsychFunc_RTT(appHandle)

global debug

if debug
    disp('Entering plotPsychFunc_RTT')
end

if debug
    disp('Exiting plotPsychFunc_RTT')
end