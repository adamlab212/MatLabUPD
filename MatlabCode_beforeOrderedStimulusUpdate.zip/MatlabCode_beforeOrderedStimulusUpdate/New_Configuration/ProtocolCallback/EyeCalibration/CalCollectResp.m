function CalCollectResp(appHandle)
global debug 

if debug
    disp('Entering collectResp')
end

if debug
    disp('Exiting collectResp')
end