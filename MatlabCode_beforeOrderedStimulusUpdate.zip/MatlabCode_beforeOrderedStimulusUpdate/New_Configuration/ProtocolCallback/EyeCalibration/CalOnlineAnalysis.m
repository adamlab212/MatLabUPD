function CalOnlineAnalysis(appHandle)
global debug 

if debug
    disp('Entering CalOnlineAnalysis');
end


if debug
    disp('Exiting CalOnlineAnalysis');
end