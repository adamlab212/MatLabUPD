function adaptPlotPsychFuncFourResponses(appHandle)

