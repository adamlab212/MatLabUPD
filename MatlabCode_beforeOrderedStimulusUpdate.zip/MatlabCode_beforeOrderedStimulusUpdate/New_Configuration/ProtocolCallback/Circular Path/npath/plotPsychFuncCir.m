function plotPsychFunc(appHandle)

global debug

if debug
    disp('Entering plotPsychFunc')
end

if debug
    disp('Exiting plotPsychFunc')
end


